import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.Scanner;

public class MainManegmentFacade implements MainManegment {
    public static MainManegmentFacade instance;

    private MainManegmentFacade() {
    }


    public static MainManegmentFacade getInstance() {
        if (instance == null) {
            instance = new MainManegmentFacade();
        }
        return instance;
    }


    public String getAllCategories() {
        StringBuilder sb = new StringBuilder();
        Product.Category[] arr = Product.Category.values();
        for (int i = 0; i < arr.length; i++) {
            sb.append(arr[i].ordinal() + "--->" + arr[i].name()).append('\n');
        }
        return sb.toString();
    }

    // the function adds a seller to the sellers array (only if the seller username does not exist in the array yet).
    public void addSellerFunction(Scanner scn, UserManagmentFacade m,Connection conn) {
        String sellerUser = UserInput.getNameFromUser(scn);
        while (m.SellerIsExist(sellerUser,conn)) {
            System.out.println("The username you entered already exist, please try again. ");
            System.out.println(" ");
            sellerUser = UserInput.getNameFromUser(scn);
        }
        m.addSellerToDataBase(scn,sellerUser,conn);

    }

    // the function adds a client to the clients array (only if the client username does not exist in the array yet).
    public void addClientFunction(Scanner scn, UserManagmentFacade m,ExeptionManegmentFacade e,Connection conn) {
        String clientuser = UserInput.getNameFromUser(scn);
        while (m.ClientIsExist(clientuser,conn)) {
            System.out.println("The username you entered already exist, please try again. ");
            System.out.println(" ");
            clientuser = UserInput.getNameFromUser(scn);
        }
        m.addClientToDataBase(scn,clientuser,e,conn);
        m.makeCartForClient(clientuser,conn);

    }


    // the function adds to seller (in the system) a product that the seller chooses.
    public void addProductToSellerFunction(Scanner scn, UserManagmentFacade m, ExeptionManegmentFacade input,Connection conn) {
        String st = m.PrintSellersFromDataBase(conn);
        if(st.charAt(0) != '1'){
            System.out.println("There are no sellers, add new sellers!");
            return;
        }
        System.out.println(st);
        System.out.print("Please enter the seller you would like to add a product to:");
        String sellerName = scn.nextLine().split(" ")[0];
        if (m.SellerIsExist(sellerName,conn)) {
            m.addProductToSeller(sellerName,scn,input,conn);
            System.out.println("The product was added successfully!");
        } else {
            System.out.println("The seller you have written does not exist in the system!");
        }

    }

    // the function adds to client's shopping cart (in the system) a product from seller (in the system).
    public void addProductToClientFunction(Scanner scn, UserManagmentFacade m, ExeptionManegmentFacade input, Connection conn) {
        String st = m.PrintClientNamesFromDataBase(conn);
        if (st.charAt(0) != '1') {
            System.out.println("There are no clients, add new clients!");
            return;
        }
        System.out.println(st);
        System.out.print("Please enter the client you would like to add a product to:");
        String clientName = scn.nextLine().split(" ")[0];
        System.out.println(" ");
        if (m.ClientIsExist(clientName,conn)) {
            String st1 = m.PrintSellerNamesFromDataBase(conn);
            if (st1.charAt(0) != '1') {
                System.out.println("There are no sellers yet, so it is impossible to add product to cart right now!");
                return;
            }
            System.out.println(st1);
            System.out.print("And now please enter the name of the seller you want to buy from:");
            String buyFromSeller = scn.nextLine().split(" ")[0];
            if (!m.SellerIsExist(buyFromSeller,conn)) {
                System.out.println("The seller does not exist!");
                return;

            } else {
                System.out.println("The sellers products: " + "\n");
                String st2 = m.printSellerProducts(buyFromSeller,conn);
                if(st2.charAt(0) == ' '){
                    System.out.println("The seller doesn't have any products yet!");
                    return;
                }
                System.out.println(st2);
                System.out.println("Please select the product id of the seller product you would like to purchase: ");
                String stringid = scn.nextLine().split(" ")[0];
                int id = input.dealWithIntegerInput(stringid, scn);
                if(m.productExistForSeller(id,buyFromSeller,conn)){
                    m.addProductToClient(clientName,id,conn);
                    System.out.println("The product was added to your cart successfully!");
                    return;
                }
                System.out.println(" The product id you selected does not exist for this seller! Please try again with another seller. ");
                return;
            }

        } else {
            System.out.println("The client you have written does not exist in the system!");
        }
    }

    // shows the Client's shopping cart and the price to pay for it, at the end the cart goes to the history carts array.
    public void payForClientsCartFunction(Scanner scn, UserManagmentFacade m, CartManegmentFacade c,Connection conn) {
        String st = m.PrintClientNamesFromDataBase(conn);
        if (st.equals("")) {
            System.out.println("There are no clients, add clients!");
            return;
        }
        System.out.println(st);
        System.out.print("Please enter the name of the client you would like to pay for:");
        String clientBill = scn.nextLine().split(" ")[0];
        if (m.ClientIsExist(clientBill,conn)) {
            if (m.totalPriceForClientCart(clientBill,conn) != 0) {
                System.out.println(m.PrintClientsProducts(clientBill,conn));
                System.out.println(" The total price to pay for the cart is: " + m.totalPriceForClientCart(clientBill,conn));
                m.makeCartIntoHistory(clientBill,conn);
                m.makeCartForClient(clientBill,conn);
                System.out.println("The payment was successful, your cart is now located in your history orders. ");
            } else {
                System.out.println(" Your cart is empty, please select items in order to pay for your cart. ");
            }
        } else {
            System.out.println("Sorry, the client does not exist in the system!");
        }
    }

    // shows all the Clients usernames in the system
    public void showClientArrayFunction(Scanner scn, UserManagmentFacade m,Connection conn) {
        System.out.println("The client's array:");
        System.out.println(m.PrintClientsFromDataBase(conn));
    }

    // shows all the sellers usernames in the system
    public void showSellerArrayFunction(Scanner scn, UserManagmentFacade m,Connection conn) {
        System.out.println("The seller's array:");
        m.PrintAllSellersProducts(conn);

    }

    public void printAllProductFromCategory(Scanner scn, ProductManagmentFacade p,UserManagmentFacade userManager, ExeptionManegmentFacade input,Connection conn) {
        System.out.println("\nAll Products Categories:");
        System.out.println(getInstance().getAllCategories());
        System.out.print(" Enter one category of products which you would like to see (CHILDREN,OFFICE,CLOTHES,ELECTRICITY): ");
        String stringCategory = scn.nextLine().split(" ")[0];
        Product.Category category = input.dealWithEnumInput(stringCategory, scn);
        System.out.println("All the products from the category you chose: ");
        p.showAllProductsFromCategory(category,userManager,conn);
    }

    public void makeNewCartFromHistoryCarts(Scanner scn, UserManagmentFacade m, CartManegmentFacade c, ExeptionManegmentFacade input,Connection conn) {
        String st = m.PrintClientNamesFromDataBase(conn);
        if (st.charAt(0) != '1') {
            System.out.println("There are no clients, add clients!");
            return;
        }
        System.out.println(st);
        System.out.print("Please enter your username: ");
        String username = scn.nextLine().split(" ")[0];
        if(m.ClientIsExist(username,conn)) {
            String s = m.printAllClientHistoryCarts(username,conn);
            if (s.equals(" ")) {
                System.out.println("This client has 0 history carts!");
                return;
            }
            else{
                System.out.println(s);
                System.out.print("please enter the history cid you would like:");
                String stringNum = scn.nextLine().split(" ")[0];
                int num = input.dealWithIntegerInput(stringNum, scn);
                m.putHistoryCartProductsToCurrentCart(username,num,conn);
            }
        }
        else{
            System.out.println("The client you entered doesn't exist");
            return;
        }
    }

    public Connection makeConnectionToDatabase() {
        Connection conn = null;
        try {
            Class.forName("org.postgresql.Driver");
            String dbUrl = "jdbc:postgresql://localhost:5432/e_commerce";
            conn = DriverManager.getConnection(dbUrl, "postgres", "Sailing301!");

        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        } catch (SQLException ex) {
            ex.printStackTrace();
        }


        return conn;


    }

    public void closeDatabaseConnection(Connection conn) throws SQLException {
        conn.close();
    }

}
