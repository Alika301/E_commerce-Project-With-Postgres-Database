import java.sql.Connection;
import java.util.*;

public interface UsersManegment {
    public String PrintSellerNamesFromDataBase(Connection conn);
    public String PrintClientNamesFromDataBase(Connection conn);
    public void addClientToDataBase(Scanner scn,String client_name,ExeptionManegmentFacade input, Connection conn);
    public String PrintClientsFromDataBase(Connection conn);
    public void addSellerToDataBase(Scanner scn,String seller_name,Connection conn);
    public String PrintSellersFromDataBase(Connection conn);
    public boolean ClientIsExist(String username, Connection conn);
    public boolean SellerIsExist(String username, Connection conn);
    public void addProductToSeller(String username,Scanner scn, ExeptionManegmentFacade input,Connection conn);
    public void PrintAllSellersProducts(Connection conn);
    public String printSellerProductsFromCategory(String username,String category, Connection conn);
    public String printSellerProducts(String username, Connection conn);
    public boolean productExistForSeller(int id,String buyFromSeller,Connection conn);
    public boolean checkIfProductInCart(int cid,int pid,Connection conn);
    public void addProductToClient(String clientName,int id,Connection conn);
    public void makeCartForClient(String client_name, Connection conn);
    public int findCartId(String client_name, Connection conn);
    public double totalPriceForClientCart(String client_name, Connection conn);
    public String PrintClientsProducts(String clientBill,Connection conn);
    public void insertToProductHistoryCart(int pid,int cid,int amount, Connection conn);
    public void makeCartIntoHistory(String clientBill,Connection conn);
    public String printAllClientHistoryCarts(String client,Connection conn);
    public void insertProductToClientCartWithAmount(int pid,int cid,int amount,Connection conn);
    public void putHistoryCartProductsToCurrentCart(String client,int history_cid,Connection conn);

}
