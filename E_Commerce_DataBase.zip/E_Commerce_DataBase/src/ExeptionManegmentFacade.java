import java.util.Scanner;

public class ExeptionManegmentFacade implements ExeptionManegment{
    public static ExeptionManegmentFacade instance;
    private ExeptionManegmentFacade(){
    }


    public static ExeptionManegmentFacade getInstance(){
        if(instance == null){
            instance = new ExeptionManegmentFacade();
        }
        return instance;
    }

    // function that deals with clients input until the client entered an integer and that it is also positive.
    public int dealWithIntegerInput(String st, Scanner scanner){
        int num = 0;
        String s = st;
        boolean isNum = false;
        while (!isNum) {
            try {
                num = Integer.parseInt(s);
                isNum = true;

            } catch (NumberFormatException e) {
                System.out.println("You were supposed to enter an integer number, please try again! ");
                s = scanner.nextLine().split(" ")[0];

            }
        }
        return num;
    }

    // function that deals with clients input until the client entered a double and that it is also positive.
    public double dealWithDoubleInput(String st, Scanner scanner){
        String s = st;
        double num = 0.0;
        boolean isNum = false;
        while (!isNum) {
            try {
                num = Double.parseDouble(s);
                if(num >= 0.0){
                    isNum = true;
                }
                else {
                    System.out.println("The number should be positive");
                    s = scanner.nextLine().split(" ")[0];
                }

            } catch (NumberFormatException e) {
                System.out.println("You were supposed to enter a decimal number, please try again! ");
                s = scanner.nextLine().split(" ")[0];

            }
        }
        return num;
    }

    // function that deals with clients input until the client entered a category from the list..
    public Product.Category dealWithEnumInput(String st, Scanner scanner){
        String s = st;
        Product.Category category = Product.Category.CHILDREN;
        boolean isEnum = false;
        while (!isEnum){
            try {
                category = Product.Category.valueOf(s.toUpperCase());
                isEnum = true;
            }
            catch (IllegalArgumentException e){
                System.out.println("You were supposed to enter a category from the list above, please try again! ");
                s = scanner.nextLine().split(" ")[0];
            }
        }
        return category;
    }

    // function that deals with clients input until the client entered yes or no.
    public String dealWithYesOrNoString(String st, Scanner scanner){
        String s = st.toLowerCase();
        boolean isYesOrNo = false;
        while (!isYesOrNo){
            if (s.equals("yes") || s.equals("no")) {
                isYesOrNo = true;
            }
            else{
                System.out.println("You were supposed to enter yes or no, please try again! ");
                s = scanner.nextLine().split(" ")[0].toLowerCase();
            }

        }
        return s;
    }
}
