public class Product {
        private String name;     // the name of the product
        private double price;       // the price of the product
        private static int ID = 1;
        private int id;
        public static enum Category { CHILDREN, ELECTRICITY, OFFICE, CLOTHES };
        private Product.Category category;
        private double specialPackaging;


        // Product copy constructor
        public Product(Product p){
            this.price = p.price;
            this.name = p.name;
            this.id = p.id;
            this.category = p.category;
            this.specialPackaging = p.specialPackaging;


        }


        // full Product constructor
        public Product( String name, double price, Product.Category categoty, double specialPackaging){
            this.name = name;
            this.price = price;
            this.id = ID++;
            this.category = categoty;
            this.specialPackaging = specialPackaging;



        }

        public double getSpecialPackaging(){
            return this.specialPackaging;
        }

        // get the product's category
        public Product.Category getCategory(){
            return this.category;
        }


        // get the product's id
        public int getId(){
            return this.id;
        }


        // get the name of the product
        public String getName(){
            return this.name;
        }

        // get the price of the product
        public double getPrice(){
            return this.price;
        }

        // toString of the Class Product
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append('\n');
            sb.append(" Product: ").append("\n").append(" Name of the product: ")
                    .append(this.getName()).append(", ").append(" Price of the product: ").append(this.getPrice()).append(", ")
                    .append(" The product's category: ").append(this.category.name());
            if( this.specialPackaging > 0.0) {
                sb.append(", ").append(" Special packaging price: ")
                        .append(this.specialPackaging);
            }
            return sb.toString();
        }
}
