import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public interface MainManegment {
    public String getAllCategories();
    public void addSellerFunction(Scanner scn, UserManagmentFacade m,Connection conn);
    public void addClientFunction(Scanner scn, UserManagmentFacade m,ExeptionManegmentFacade e,Connection conn);
    public void addProductToSellerFunction(Scanner scn, UserManagmentFacade m, ExeptionManegmentFacade input,Connection conn);
    public void addProductToClientFunction(Scanner scn, UserManagmentFacade m, ExeptionManegmentFacade input, Connection conn);
    public void payForClientsCartFunction(Scanner scn, UserManagmentFacade m, CartManegmentFacade c,Connection conn);
    public void showClientArrayFunction(Scanner scn, UserManagmentFacade m,Connection conn);
    public void showSellerArrayFunction(Scanner scn, UserManagmentFacade m,Connection conn);
    public void printAllProductFromCategory(Scanner scn, ProductManagmentFacade p,UserManagmentFacade userManager, ExeptionManegmentFacade input,Connection conn);
    public void makeNewCartFromHistoryCarts(Scanner scn, UserManagmentFacade m, CartManegmentFacade c, ExeptionManegmentFacade input,Connection conn);
    public Connection makeConnectionToDatabase();
    public void closeDatabaseConnection(Connection conn) throws SQLException;
}
