import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ProductManagmentFacade implements ProductManegment {
    public static ProductManagmentFacade instance;

    private ProductManagmentFacade() {
    }

    public static ProductManagmentFacade getInstance() {
        if (instance == null) {
            instance = new ProductManagmentFacade();
        }
        return instance;
    }
    // function that shows all the products from all the sellers from a certain category.
    @Override
    public void showAllProductsFromCategory(Product.Category category,UserManagmentFacade m, Connection conn) {
        String s = "";
        int index = 1;
        String username = "";
        String sql = "SELECT username FROM seller;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                username = rs.getString("username");
                System.out.println(index + ". " + (username) + "'s products in category " + category.toString() + ":\n");
                s = m.printSellerProductsFromCategory(username,category.toString(), conn);
                if (s.equals(" ")) {
                    System.out.println("This seller has 0 products in this category!");
                }
                else{
                    System.out.println(s);
                }
                index ++;

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}


