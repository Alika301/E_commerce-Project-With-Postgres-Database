import java.sql.Connection;
import java.sql.ResultSet;
import java.time.LocalDate;
import java.util.*;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class UserManagmentFacade implements UsersManegment {
    public static UserManagmentFacade instance;
    private UserManagmentFacade() {
    }

    public static UserManagmentFacade getInstance() {
        if (instance == null) {
            instance = new UserManagmentFacade();
        }
        return instance;
    }

    public void addClientToDataBase(Scanner scn,String client_name,ExeptionManegmentFacade input, Connection conn) {
        String pass = UserInput.getPasswordFromUser(scn);
        String city = UserInput.getCityFromUser(scn);
        String street = UserInput.getStreetFromUser(scn);
        int homenum = input.dealWithIntegerInput(UserInput.getHomenumberFromUser(scn),scn);

        String sql = "INSERT INTO client (username, password, city,street, homenumber) VALUES (?, ?, ?,?,?)";
        try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, client_name);
            pstmt.setString(2, pass);
            pstmt.setString(3, city);
            pstmt.setString(4, street);
            pstmt.setInt(5, homenum);
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new client was inserted successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public String PrintClientsFromDataBase(Connection conn){
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT username,city,street,homenumber FROM client";
        int index = 1;

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String username = rs.getString("username");
                String city = rs.getString("city");
                String street = rs.getString("street");
                int homenumber = rs.getInt("homenumber");
                sb.append(index).append(". ").append("username: ").append(username).append(", city: ").append(city)
                        .append(", street: ").append(street).append(", homenumber: ").append(homenumber)
                        .append("\nclient's cart: ").append(PrintClientsProducts(username,conn)).append("\n");
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    public void addSellerToDataBase(Scanner scn,String seller_name,Connection conn) {
        String pass = UserInput.getPasswordFromUser(scn);
        String sql = "INSERT INTO seller (username, password) VALUES (?, ?)";
        try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, seller_name);
            pstmt.setString(2, pass);
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new seller was inserted successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public String PrintSellersFromDataBase(Connection conn){
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT username FROM seller";
        int index = 1;

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String username = rs.getString("username");
                sb.append(index).append(". ").append(username).append("\n");
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    public boolean ClientIsExist(String username, Connection conn) {
        String user = "";
        String sql = "SELECT username FROM client WHERE username = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    user = rs.getString("username");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (user == ""){
            return false;
        }
        return true;
    }
    public boolean SellerIsExist(String username, Connection conn){
        String user = "";
        String sql = "SELECT username FROM seller WHERE username = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, username);
            try (ResultSet rs = pstmt.executeQuery()) {
                while (rs.next()) {
                    user = rs.getString("username");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (user == ""){
            return false;
        }
        return true;
    }
    public void addProductToSeller(String username,Scanner scn, ExeptionManegmentFacade input,Connection conn){
        System.out.print("And now please enter the name of the product you want to add:");
        String productName = scn.nextLine();
        System.out.print("please enter the price of the product you want to add:");
        String stringPrice = scn.nextLine().split(" ")[0];
        double productPrice = input.dealWithDoubleInput(stringPrice, scn);
        System.out.println("please enter the category of the product:");
        System.out.println("\nAll Product Categories:");
        System.out.println(MainManegmentFacade.getInstance().getAllCategories());
        System.out.print("\nWhat is the product's category?");
        String stringCategory = scn.nextLine().split(" ")[0];
        Product.Category category = input.dealWithEnumInput(stringCategory, scn);
        System.out.print("what is the price of the special packaging? ");
        String priceForPackagingString = scn.nextLine().split(" ")[0];
        double priceForPackaging = input.dealWithDoubleInput(priceForPackagingString, scn);

        String sql = "INSERT INTO product (name, price,category,specialpackeging,seller) VALUES (?, ?, ?, ?, ?)";
        try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, productName);
            pstmt.setDouble(2, productPrice);
            pstmt.setString(3,category.toString());
            pstmt.setDouble(4, priceForPackaging);
            pstmt.setString(5,username);
            int rowsInserted = pstmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new product has been added to seller successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void PrintAllSellersProducts(Connection conn){
        String s = "";
        int index = 1;
        String username = "";
        String sql = "SELECT username FROM seller;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                username = rs.getString("username");
                System.out.println(index +". "+ (username) + " products: " + "\n");
                s = printSellerProducts(username,conn);
                if(s.equals("")){
                    System.out.println("The seller has 0 products!");
                }
                else {
                    System.out.println(s);
                }
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    public String PrintSellerNamesFromDataBase(Connection conn){
        StringBuilder sb = new StringBuilder();
        String sql = "SELECT username FROM seller";
        int index = 1;

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String username = rs.getString("username");
                sb.append(index).append(". ").append(username).append("\n");
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    public String PrintClientNamesFromDataBase(Connection conn){
        StringBuilder sb = new StringBuilder("");
        String sql = "SELECT username FROM client";
        int index = 1;

        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {

            while (rs.next()) {
                String username = rs.getString("username");
                sb.append(index).append(". ").append(username).append("\n");
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    public String printSellerProductsFromCategory(String username,String category, Connection conn){
        StringBuilder sb = new StringBuilder(" ");
        int index = 1;
        String sql = "SELECT pid,name,price,category,specialpackeging  FROM product WHERE seller = ? AND category = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)){
            pstmt.setString(1,username);
            pstmt.setString(2,category);
             ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                sb.append((index)).append(". pid = ").append(rs.getInt("pid")).append(", pname = ").append(rs.getString("name")).append(", price = ").append(rs.getDouble("price")).append(", category = ").append(rs.getString("category")).append(", special packeging = ").append(rs.getInt("specialpackeging")).append("\n");
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    public String printSellerProducts(String username, Connection conn){
        StringBuilder sb = new StringBuilder("");
        int index = 1;
        String sql = "SELECT pid,name,price,category,specialpackeging  FROM product WHERE seller = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)){
             pstmt.setString(1,username);
             ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                sb.append(". pid = ").append(rs.getInt("pid")).append(", pname = ").append(rs.getString("name")).append(", price = ").append(rs.getDouble("price")).append(", category = ").append(rs.getString("category")).append(", special packeging = ").append(rs.getInt("specialpackeging")).append("\n");
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return sb.toString();
    }
    public boolean productExistForSeller(int id,String buyFromSeller,Connection conn){
        int num = 0;
        String sql = "SELECT pid AS count FROM product WHERE seller = ? AND pid = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)){
            pstmt.setString(1,buyFromSeller);
            pstmt.setInt(2,id);
             ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                num = rs.getInt("count");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (num == 0){
            return false;
        }
        return true;
    }
    public boolean checkIfProductInCart(int cid,int pid,Connection conn){
        int pid_rs = -1;
        String sql = "SELECT pid FROM product_cart WHERE pid = ? AND cid = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)){
            pstmt.setInt(1,pid);
            pstmt.setInt(2,cid);
             ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                pid_rs = rs.getInt("pid");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        if (pid_rs == -1){
            return false;
        }
        return true;
    }
    public void addProductToClient(String clientName,int id,Connection conn){
        int cid = findCartId(clientName,conn);

        if (checkIfProductInCart(cid,id,conn)) {
            String sql = "UPDATE product_cart SET amount = amount + 1 WHERE pid = ? AND cid = ?;";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, id);
                pstmt.setInt(2, cid);
                pstmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        else {
            String sql = "INSERT INTO product_cart (cid,pid) VALUES (?,?)";
            try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
                pstmt.setInt(1, cid);
                pstmt.setInt(2, id);
                pstmt.executeUpdate();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
    public void makeCartForClient(String client_name, Connection conn){
        String sql = "INSERT INTO cart (client) VALUES (?)";
        try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, client_name);
            pstmt.executeUpdate();
        } catch (SQLException e) {
                e.printStackTrace();
        }

    }
    public int findCartId(String client_name, Connection conn){
        int id = -1;
        String sql = "SELECT cid FROM cart WHERE client = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql)){
            pstmt.setString(1,client_name);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                id = rs.getInt("cid");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }
    public double totalPriceForClientCart(String client_name, Connection conn) {
        int cid = findCartId(client_name, conn);
        double sum = 0.0;

        String sql = """
        SELECT SUM(p.price * pc.amount) AS total
        FROM product p
        INNER JOIN product_cart pc ON p.pid = pc.pid
        WHERE pc.cid = ?
        """;

        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cid);

            try (ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    sum = rs.getDouble("total");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sum;
    }
    public String PrintClientsProducts(String clientBill,Connection conn){
        StringBuilder sb = new StringBuilder(" ");
        int cid = findCartId(clientBill,conn);
        int index = 1;
        String sql = " SELECT p.pid, p.name,p.price,p.category,p.specialpackeging,pc.amount FROM product p INNER JOIN product_cart pc ON p.pid = pc.pid WHERE pc.cid = ?;" ;
        try (PreparedStatement pstmt = conn.prepareStatement(sql)){
            pstmt.setInt(1, cid);
            ResultSet rs = pstmt.executeQuery();


            while (rs.next()) {
                int pid = rs.getInt(1);
                String name = rs.getString(2);
                double price = rs.getDouble(3);
                String category = rs.getString(4);
                double specialpackeging = rs.getDouble(5);
                int amount = rs.getInt(6);
                sb.append((index)).append(". pid = ").append(pid).append(", name = ").append(name).append(", price = ").append(price).append(", category = ").append(category).append(", specialpackeging = ").append(specialpackeging).append(", amount = ").append(amount).append("\n");
                index++;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return sb.toString();
    }
    public void insertToProductHistoryCart(int pid,int cid,int amount, Connection conn){
        String sql0 = "INSERT INTO product_history_cart (cid,pid,amount) VALUES (?,?,?)";
        try(PreparedStatement pstmt0 = conn.prepareStatement(sql0)) {
            pstmt0.setInt(1, cid);
            pstmt0.setInt(2, pid);
            pstmt0.setInt(3, amount);
            pstmt0.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void makeCartIntoHistory(String clientBill,Connection conn){
        int cid = findCartId(clientBill,conn);
        String sql = "INSERT INTO history_cart (cid,client,date) VALUES (?,?,?)";
        try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cid);
            pstmt.setString(2, clientBill);
            pstmt.setString(3, LocalDate.now().toString());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sql0 = "SELECT pid,amount FROM product_cart WHERE cid = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql0)){
             pstmt.setInt(1,cid);
             ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int pid = rs.getInt("pid");
                int amount = rs.getInt("amount");
                insertToProductHistoryCart(pid,cid,amount,conn);
             }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sql2 = "DELETE FROM product_cart WHERE cid = ?";
        try(PreparedStatement pstmt2 = conn.prepareStatement(sql2)) {
            pstmt2.setInt(1, cid);
            pstmt2.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        String sql1 = "DELETE FROM cart WHERE cid = ? AND client = ?";
        try(PreparedStatement pstmt1 = conn.prepareStatement(sql1)) {
            pstmt1.setInt(1, cid);
            pstmt1.setString(2, clientBill);
            pstmt1.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }
    public String printAllClientHistoryCarts(String client,Connection conn){
        StringBuilder sb = new StringBuilder(" ");
        int index = 1;
        String sql0 = "SELECT cid,date FROM history_cart WHERE client = ?;";
        try (PreparedStatement pstmt0 = conn.prepareStatement(sql0)){
            pstmt0.setString(1,client);
            ResultSet rs0 = pstmt0.executeQuery();

            while (rs0.next()) {
                int cid = rs0.getInt("cid");
                String date = rs0.getString("date");
                sb.append("cid number - ").append(cid).append(" ,date - ").append(date).append(" with products:\n");
                String sql = """
        SELECT p.pid, p.name,p.price,p.category,p.specialpackeging,pc.amount
        FROM product p
        INNER JOIN product_history_cart pc ON p.pid = pc.pid
        WHERE pc.cid = ?
        """;
                try (PreparedStatement pstmt = conn.prepareStatement(sql)){
                    pstmt.setInt(1,cid);
                    ResultSet rs = pstmt.executeQuery();

                    while (rs.next()) {
                        sb.append((index)).append(". pid = ").append(rs.getInt("pid")).append(", pname = ").append(rs.getString("name")).append(", price = ").append(rs.getDouble("price")).append(", category = ").append(rs.getString("category")).append(", special packeging = ").append(rs.getInt("specialpackeging")).append("\n");
                        index++;
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


        return sb.toString();
    }
    public void insertProductToClientCartWithAmount(int pid,int cid,int amount,Connection conn){
        String sql = "INSERT INTO product_cart (cid,pid,amount) VALUES (?,?,?)";
        try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, cid);
            pstmt.setInt(2, pid);
            pstmt.setInt(3, amount);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public void putHistoryCartProductsToCurrentCart(String client,int history_cid,Connection conn){
        //delete all the products in clients current cart
        int current_cid = findCartId(client,conn);
        String sql = "DELETE FROM product_cart WHERE cid = ?";
        try(PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, current_cid);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        //insert all pid to product_cart from product_history_cart
        String sql0 = "SELECT pid,amount FROM product_history_cart WHERE cid = ?;";
        try (PreparedStatement pstmt = conn.prepareStatement(sql0)){
             pstmt.setInt(1,history_cid);
             ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                int pid = rs.getInt("pid");
                int amount = rs.getInt("amount");
                insertProductToClientCartWithAmount(pid,current_cid,amount,conn);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
