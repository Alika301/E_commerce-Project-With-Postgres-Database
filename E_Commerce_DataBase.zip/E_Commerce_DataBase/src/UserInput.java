import java.util.Scanner;

public class UserInput {
    public static String getNameFromUser(Scanner scn){
        System.out.print("Please enter a name: ");
        String name = scn.nextLine().split(" ")[0];
        return name;
    }
    public static String getCityFromUser(Scanner scn){
        System.out.print("Please enter your city: ");
        String city = scn.nextLine();
        return city;
    }
    public static String getStreetFromUser(Scanner scn){
        System.out.print("Please enter your Street: ");
        String street = scn.nextLine();
        return street;
    }
    public static String getHomenumberFromUser(Scanner scn){
        System.out.print("Please enter your home number: ");
        String homenum = scn.nextLine().split(" ")[0];
        return homenum;
    }
    public static String getPasswordFromUser(Scanner scn){
        System.out.print("Please enter your password: ");
        String password = scn.nextLine().split(" ")[0];
        return password;
    }
    public static int getPriceFromUser(Scanner scn){
        System.out.print("Please enter a price: ");
        int price = Integer.parseInt(scn.nextLine().split(" ")[0]);
        return price;
    }

    public static double getSpecialPackagingFromUser(Scanner scn){
        System.out.print("Please enter special packaging: ");
        double special = Double.parseDouble(scn.nextLine().split(" ")[0]);
        return special;
    }
    public static Product.Category getCategoryFromUser(Scanner scn,ExeptionManegmentFacade input,MainManegmentFacade m){
        System.out.println(m.getAllCategories());
        System.out.print("\nWhat is the product's category?");
        String stringCategory = scn.nextLine().split(" ")[0];
        Product.Category category = input.dealWithEnumInput(stringCategory, scn);
        return category;
    }
}
