import java.sql.Connection;
import java.util.Comparator;

public interface ProductManegment {
    // function that shows all the products from all the sellers from a certain category.
    public void showAllProductsFromCategory(Product.Category category,UserManagmentFacade m,Connection conn);




}
