public class CartManegmentFacade implements CartManegment{
    public static CartManegmentFacade instance;
    private CartManegmentFacade(){
    }

    public static CartManegmentFacade getInstance(){
        if(instance == null){
            instance = new CartManegmentFacade();
        }
        return instance;
    }

}
