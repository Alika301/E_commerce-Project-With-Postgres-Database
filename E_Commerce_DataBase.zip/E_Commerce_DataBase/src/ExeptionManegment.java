import java.util.Scanner;

public interface ExeptionManegment {
    public int dealWithIntegerInput(String st, Scanner scanner);
    public double dealWithDoubleInput(String st, Scanner scanner);
    public Product.Category dealWithEnumInput(String st, Scanner scanner);
    public String dealWithYesOrNoString(String st, Scanner scanner);

}
