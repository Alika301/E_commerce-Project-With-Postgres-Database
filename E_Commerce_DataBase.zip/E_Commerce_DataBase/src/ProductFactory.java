import java.util.Scanner;

public class ProductFactory {
    public Product CreateProduct(Scanner scn, ExeptionManegmentFacade input,MainManegmentFacade m){
        String name = UserInput.getNameFromUser(scn);
        int price = UserInput.getPriceFromUser(scn);
        Product.Category category = UserInput.getCategoryFromUser(scn, input,m);
        double special = UserInput.getSpecialPackagingFromUser(scn);
        return new Product(name,price,category,special);
    }
}
