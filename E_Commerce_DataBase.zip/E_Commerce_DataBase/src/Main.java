// Pini Shlomi's class
//215365370 Alika Bochkaryov
//315158014 Eden Alalin

import java.sql.Connection;
import java.sql.SQLException;
import java.util.*;

public class Main{
    public static Scanner scn = new Scanner(System.in);
    public static void main(String[] args) throws ClassNotFoundException, SQLException {
        Connection db_conn = MainManegmentFacade.getInstance().makeConnectionToDatabase(); //make connection to database
        MainManegmentFacade main = MainManegmentFacade.getInstance();
        UserManagmentFacade userManager = UserManagmentFacade.getInstance();
        ExeptionManegmentFacade inputHandler = ExeptionManegmentFacade.getInstance();
        CartManegmentFacade c = CartManegmentFacade.getInstance();
        ProductManagmentFacade p = ProductManagmentFacade.getInstance();


        System.out.println("Please choose an option:");
        System.out.println("Enter 0 to exit.");
        System.out.println("Enter 1 to add a Seller.");
        System.out.println("Enter 2 to add a Client.");
        System.out.println("Enter 3 to add a product for Seller.");
        System.out.println("Enter 4 to add a product for Client.");
        System.out.println("Enter 5 to pay for Client's order.");
        System.out.println("Enter 6 to show information about all the Clients.");
        System.out.println("Enter 7 to show information about all the Sellers.");
        System.out.println("Enter 8 to show all the products from a certain category from all the sellers.");
        System.out.print("Enter 9 to make a new cart from one of the client's history carts.");

        String stringChoice = scn.nextLine().split(" ")[0];
        int choice = inputHandler.dealWithIntegerInput(stringChoice, scn);
        System.out.println(" ");
        if(choice == 0){
            System.exit(0);
        }
        do{
            switch (choice) {
                case 1: {
                    main.addSellerFunction(scn,userManager,db_conn);
                    break;
                }
                case 2: {
                    main.addClientFunction(scn,userManager,inputHandler,db_conn);
                    break;
                }
                case 3: {
                    main.addProductToSellerFunction(scn, userManager, inputHandler,db_conn);
                    break;

                }
                case 4: {
                    main.addProductToClientFunction(scn, userManager, inputHandler,db_conn);
                    break;
                }
                case 5: {
                    main.payForClientsCartFunction(scn, userManager,c,db_conn);
                    break;
                }
                case 6: {
                    main.showClientArrayFunction(scn, userManager,db_conn);
                    break;
                }
                case 7: {
                    main.showSellerArrayFunction(scn, userManager,db_conn);
                    break;
                }
                case 8: {
                     main.printAllProductFromCategory(scn, p,userManager, inputHandler,db_conn);
                     break;
                }
                case 9:{
                    main.makeNewCartFromHistoryCarts(scn, userManager,c, inputHandler,db_conn);
                    break;
                }
                default:{
                    System.out.println("Incorrect input, please choose an option again!");
                    break;
                }


            }


            System.out.println(" ");
            System.out.println("Please choose an option:");
            System.out.println("Enter 0 to exit.");
            System.out.println("Enter 1 to add a Seller.");
            System.out.println("Enter 2 to add a Client.");
            System.out.println("Enter 3 to add a product for Seller.");
            System.out.println("Enter 4 to add a product for Client.");
            System.out.println("Enter 5 to pay for Client's order.");
            System.out.println("Enter 6 to show information about all the Clients.");
            System.out.println("Enter 7 to show information about all the Sellers.");
            System.out.println("Enter 8 to show all the products from a certain category from all the sellers.");
            System.out.print("Enter 9 to make a new cart from one of the client's history carts.");
            stringChoice = scn.nextLine().split(" ")[0];
            choice = inputHandler.dealWithIntegerInput(stringChoice, scn);
            System.out.println(" ");
        }
        while (choice != 0);
        scn.close();
        main.closeDatabaseConnection(db_conn);
    }


}
