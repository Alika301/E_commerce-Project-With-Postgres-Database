--CREATE DATABASE e_commerce;

--client
CREATE TABLE client(
	username VARCHAR(50) NOT NULL,
	password VARCHAR(50) NOT NULL,
	city VARCHAR(50),
	street VARCHAR(50),
	homenumber INT,
	PRIMARY KEY(username)
);

--seller
CREATE TABLE seller(
	username VARCHAR(50) NOT NULL,
	password VARCHAR(50) NOT NULL,
	PRIMARY KEY(username)
);

--product
CREATE TABLE product(
	pid SERIAL PRIMARY KEY,
	category VARCHAR(50) NOT NULL,
	specialpackeging DOUBLE PRECISION,
	price DOUBLE PRECISION,
	name VARCHAR(50) NOT NULL,
	seller VARCHAR(50) NOT NULL,
	FOREIGN KEY(seller) REFERENCES seller(username)
	
);

--cart
CREATE TABLE cart(
	cid SERIAL PRIMARY KEY,
	client VARCHAR(50) NOT NULL,
	FOREIGN KEY(client) REFERENCES client(username)
);

--product_cart
CREATE TABLE product_cart(
	amount INT default 1,
	cid INT NOT NULL,
	pid INT NOT NULL,
	PRIMARY KEY(pid,cid),
	FOREIGN KEY(pid) REFERENCES product(pid),
 	FOREIGN KEY(cid) REFERENCES cart(cid)
);

--history_cart
CREATE TABLE history_cart(
	cid SERIAL PRIMARY KEY,
	client VARCHAR(50) NOT NULL,
	date VARCHAR(50),
	FOREIGN KEY(client) REFERENCES client(username)
);
--product_history_cart
CREATE TABLE product_history_cart(
	amount INT default 1,
	cid INT NOT NULL,
	pid INT NOT NULL,
	PRIMARY KEY(pid,cid),
	FOREIGN KEY(pid) REFERENCES product(pid),
 	FOREIGN KEY(cid) REFERENCES history_cart(cid)
);

--Insert Commands
INSERT INTO client(username,password,city, street, homenumber)
VALUES ('Ben','123','Tel Aviv','beer',2),('Iris','235','Rishon','Narkis',24);

INSERT INTO seller(username,password)
VALUES ('Ana','123'),('Ben','234');

INSERT INTO product(name,price,category,specialpackeging,seller)
VALUES ('shirt',12.3 , 'CHILDREN', 1, 'Ana'),('hat', 45.7, 'CLOTHES', 2, 'Ben');

INSERT INTO cart(client)
VALUES ('Iris'),('Ben');

INSERT INTO product_cart(cid,pid,amount)
VALUES (1,1,1),(2,2,1);